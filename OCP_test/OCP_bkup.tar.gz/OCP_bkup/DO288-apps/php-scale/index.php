<?php
  print "This is version 1 of the app. I am running on host -> " . gethostname() ." (" . $_SERVER['SERVER_ADDR'] . ")" . "\n";
?>
