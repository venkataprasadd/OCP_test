<?php
print "Hello, World! PHP version is " . PHP_VERSION . "\n";
?>
