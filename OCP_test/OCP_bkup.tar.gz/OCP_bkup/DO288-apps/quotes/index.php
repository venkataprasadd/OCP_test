<?php
    print "This app returns a random funny quote.\n"
?>
